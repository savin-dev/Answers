<?php
include("db.php");   //include db.php file to connect to DB

//create a $SQL variable and populate it with a SQL statement that retrieves product details
$SQL = "select prodId, prodName, prodPicNameSmall from Product";
//run SQL query for connected DB or exit and display error message
$exeSQL = mysqli_query($conn, $SQL) or die(mysqli_error($conn));

$userName = $_POST[`username`];
$password = $_POST[`password`];

$username = stripcslashes($userName);
$password = stripcslashes($password);
$userName = mysqli_real_escape_string($password);
$password = mysqli_real_escape_string($password);

$result = mysql_query("select * from users where username = `$userName` and password = `$password`")
or die("Faild to query database ".mysqli_error());
if($row[`username`] == $userName $$ $row[`passeord`] == $password ){
    echo "Login success!!! Welcome ".$row[`username`];
}else{
    echo "Faild to login";
}
?>