import React, {Component} from "react";
import axios from "axios";
import {Button, Container, Row, Col, Form, FormControl} from 'react-bootstrap';

class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
            userName: '',
            password: '',
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        this.setState({[event.target.id]: event.target.value});
    }

    handleSubmit(event) {
        axios.put("http://localhost:8080/api/clubs",
            this.state
        ).then((res) => {
            if (res.status === 200)
                alert("Login successfully");
        }).catch((err) => {
            console.log(err);
        })
        event.preventDefault();
    }

    render() {
        return (
            <Container>
                <Row>
                    <h1>
                        Login
                    </h1>
                </Row>
                <Form onSubmit={this.handleSubmit}>
                    
                    <Form.Group as={Row} controlId="formHorizontalEmail">
                        <Form.Label column sm={2}>
                            Username :
                        </Form.Label>
                        <Col sm={10}>
                            <Form.Control type="text" id={"coachName"} value={this.state.userName}
                                   onChange={this.handleChange}/>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} controlId="formHorizontalEmail">
                        <Form.Label column sm={2}>
                            Password :
                        </Form.Label>
                        <Col sm={10}>
                            <Form.Control
                                type="text" id={"captianName"} value={this.state.password}
                                   onChange={this.handleChange}/>
                        </Col>
                    </Form.Group>
                    <Row>
                        <Col>

                        </Col>
                        <Col>
                            <Button onClick={this.handleSubmit}>Login</Button>
                        </Col>
                    </Row>
                </Form>
            </Container>
        );
    }
}

export default Login;
