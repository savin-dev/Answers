import React, {Component} from "react";
import axios from "axios";
import {Button, Container, Row, Col, Form} from 'react-bootstrap';

class Deatils extends Component {
    render() {
        return (
            <Container>
                <Row>
                    <h1>
                        Details page
                    </h1>
                </Row>
            </Container>
        );
    }
}
export default Details;