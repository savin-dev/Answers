import './App.css';
import Routes from "./Routes";
import 'bootstrap/dist/css/bootstrap.min.css';
import React from "react";
import {Button, Navbar, Nav, Form, FormControl} from 'react-bootstrap';

function App() {
    return (
        <React.Fragment>
        {/*NavBar*/}
            <Navbar bg="primary" variant="dark" className={"mb-3"}>
                <Navbar.Brand href="#home">Ombio</Navbar.Brand>
                <Nav className="mr-auto">
                    <Nav.Link href="/">Login</Nav.Link>
                    {/*<Nav.Link href="/delete">Delete Teams</Nav.Link>*/}
                </Nav>
                <Form inline>
                    <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                    <Button variant="outline-light">Search</Button>
                </Form>
            </Navbar>
            <Routes/>
        </React.Fragment>
    );
}

export default App;
